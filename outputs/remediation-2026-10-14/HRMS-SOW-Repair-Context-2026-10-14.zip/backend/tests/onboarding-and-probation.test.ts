/**
 * Stage 3.1 Test Suite — Onboarding Bridge & Probation Engine (Cards L01, L02).
 *
 * Verifies:
 * 1. Pre-join token generation, hash verification, single-use, and 72h expiration.
 * 2. Duplicate detection against employee master on email, mobile, and PAN.
 * 3. Atomic HR Conversion Wizard: core.employees, core.users, probation salary,
 *    stakeholder tasks fan-out, and initial probation review.
 * 4. Task SLA tracking, auto-escalation sweep, and Kent biometric verification.
 * 5. Probation evaluation workflow, confirmed-phase salary transition (100% CTC),
 *    and confirmation letter generation.
 */

import { describe, it, expect } from 'vitest';
import type { Kysely } from 'kysely';
import type { Database } from '../src/core/db/types.js';
import {
  PrejoinService,
  type PrejoinSubmissionData,
} from '../src/modules/lifecycle/onboarding/prejoin.service.js';
import {
  OnboardingService,
  type IngestCandidateInput,
  type ConvertCandidateInput,
} from '../src/modules/lifecycle/onboarding/onboarding.service.js';
import { TaskFanoutService } from '../src/modules/lifecycle/onboarding/task-fanout.service.js';
import { ProbationService } from '../src/modules/lifecycle/probation/probation.service.js';

describe('Phase 3, Stage 3.1 — Onboarding Bridge & Probation Management', () => {
  // In-memory state mock for isolated unit testing
  const candidatesStore: any[] = [];
  const employeesStore: any[] = [];
  const usersStore: any[] = [];
  const salariesStore: any[] = [];
  const tasksStore: any[] = [];
  const reviewsStore: any[] = [];
  const lettersStore: any[] = [];
  const companiesStore = [{ id: 1, ecode_prefix: 'RML', ecode_next_seq: 35390 }];

  const mockDb = {
    selectFrom: (table: string) => {
      const b: any = {
        _where: [] as any[],
        _joins: [] as any[],
        selectAll: () => b,
        select: () => b,
        leftJoin: () => b,
        innerJoin: () => b,
        orderBy: () => b,
        where: (colOrFn: any, op?: any, val?: any) => {
          if (typeof colOrFn === 'function') {
            const mockEb: any = (col: string, op1: string, val1: any) => ({ col, op: op1, val: val1 });
            mockEb.or = (arr: any[]) => {
              for (const item of arr) {
                if (item?.col) b._where.push(item);
              }
            };
            colOrFn(mockEb);
          } else {
            b._where.push({ col: colOrFn, op, val });
          }
          return b;
        },
        executeTakeFirst: () => {
          if (table === 'core.onboarding_candidates') {
            const tokenHashWhere = b._where.find((w: any) => w.col === 'prejoin_token_hash');
            const idWhere = b._where.find((w: any) => w.col === 'id');
            if (tokenHashWhere) {
              const c = candidatesStore.find((x) => x.prejoin_token_hash === tokenHashWhere.val);
              return Promise.resolve(c ?? null);
            }
            if (idWhere) {
              const c = candidatesStore.find((x) => x.id === idWhere.val);
              return Promise.resolve(c ?? null);
            }
          }
          if (table === 'core.employees') {
            const emailWheres = b._where.filter((w: any) => w.col === 'personal_email' || w.col === 'work_email');
            const mobileWhere = b._where.find((w: any) => w.col === 'mobile');
            const panWhere = b._where.find((w: any) => w.col === 'pan');
            if (emailWheres.length > 0) {
              const targetVal = emailWheres[0]?.val;
              const e = employeesStore.find((x) => x.personal_email === targetVal || x.work_email === targetVal);
              return Promise.resolve(e ?? null);
            }
            if (mobileWhere) {
              const e = employeesStore.find((x) => x.mobile === mobileWhere.val);
              return Promise.resolve(e ?? null);
            }
            if (panWhere) {
              const e = employeesStore.find((x) => x.pan === panWhere.val);
              return Promise.resolve(e ?? null);
            }
          }
          if (table === 'core.companies') {
            return Promise.resolve(companiesStore[0]);
          }
          if (table === 'core.onboarding_tasks') {
            const idWhere = b._where.find((w: any) => w.col === 'id');
            const t = tasksStore.find((x) => x.id === idWhere?.val);
            return Promise.resolve(t ?? null);
          }
          if (table === 'core.probation_reviews') {
            const idWhere = b._where.find((w: any) => w.col === 'id');
            const r = reviewsStore.find((x) => x.id === idWhere?.val);
            return Promise.resolve(r ?? null);
          }
          return Promise.resolve(null);
        },
        execute: () => {
          if (table === 'core.onboarding_tasks') {
            const statusWhere = b._where.find((w: any) => w.col === 'status');
            const dueWhere = b._where.find((w: any) => w.col === 'due_date');
            if (statusWhere && dueWhere && dueWhere.op === '<') {
              const overdue = tasksStore.filter((t) => t.status === 'open' && t.due_date < dueWhere.val);
              return Promise.resolve(overdue);
            }
            return Promise.resolve(tasksStore);
          }
          if (table === 'core.probation_reviews as pr') {
            return Promise.resolve(
              reviewsStore.map((pr) => {
                const emp = employeesStore.find((e) => e.id === pr.employee_id) ?? {
                  ecode: 'RML035390',
                  first_name: 'Test',
                  last_name: 'Emp',
                  doj: '2026-01-01',
                };
                return {
                  id: pr.id,
                  employeeId: pr.employee_id,
                  ecode: emp.ecode,
                  first_name: emp.first_name,
                  last_name: emp.last_name,
                  departmentName: 'Production',
                  designationName: 'Graduate Trainee',
                  doj: emp.doj,
                  dueDate: pr.due_date,
                  managerRecommendation: pr.manager_recommendation,
                  extensionMonths: pr.extension_months,
                  reviewNotes: pr.review_notes,
                  status: pr.status,
                  outcome: pr.outcome,
                  confirmationDate: pr.confirmation_date,
                };
              })
            );
          }
          if (table === 'core.probation_reviews') {
            const dueWhere = b._where.find((w: any) => w.col === 'due_date');
            if (dueWhere && Array.isArray(dueWhere.val)) {
              const valStrings = dueWhere.val.map((v: any) => {
                if (v instanceof Date) return v.toISOString().slice(0, 10);
                if (typeof v?.toOperationNode === 'function') {
                  const node = v.toOperationNode();
                  const p = node.parameters?.[0];
                  if (p && typeof p.value === 'string') return p.value;
                }
                return String(v).slice(0, 10);
              });
              const matched = reviewsStore.filter((r) => {
                const rDueStr = (r.due_date instanceof Date ? r.due_date.toISOString() : String(r.due_date)).slice(0, 10);
                return r.status === 'pending' && valStrings.includes(rDueStr);
              });
              return Promise.resolve(matched);
            }
            return Promise.resolve(reviewsStore);
          }
          return Promise.resolve([]);
        },
      };
      return b;
    },
    insertInto: (table: string) => {
      const b: any = {
        values: (val: any) => {
          b._val = val;
          return b;
        },
        returning: () => b,
        executeTakeFirstOrThrow: () => {
          const id = Date.now() + Math.floor(Math.random() * 1000);
          const record = { id, ...b._val };
          if (table === 'core.onboarding_candidates') candidatesStore.push(record);
          if (table === 'core.employees') employeesStore.push(record);
          if (table === 'core.users') usersStore.push(record);
          if (table === 'pay.employee_salaries') salariesStore.push(record);
          if (table === 'core.onboarding_tasks') tasksStore.push(record);
          if (table === 'core.probation_reviews') reviewsStore.push(record);
          if (table === 'core.letters') lettersStore.push(record);
          return Promise.resolve({ id });
        },
        executeTakeFirst: () => {
          const id = Date.now() + Math.floor(Math.random() * 1000);
          const record = { id, ...b._val };
          if (table === 'core.letters') lettersStore.push(record);
          return Promise.resolve({ id });
        },
        execute: () => {
          const id = Date.now() + Math.floor(Math.random() * 1000);
          const record = { id, ...b._val };
          if (table === 'core.users') usersStore.push(record);
          if (table === 'core.onboarding_tasks') tasksStore.push(record);
          if (table === 'pay.employee_salaries') salariesStore.push(record);
          if (table === 'core.probation_reviews') reviewsStore.push(record);
          if (table === 'core.letters') lettersStore.push(record);
          return Promise.resolve();
        },
      };
      return b;
    },
    updateTable: (table: string) => {
      const b: any = {
        _set: {} as any,
        _where: [] as any[],
        set: (patch: any) => {
          b._set = patch;
          return b;
        },
        where: (col: string, op: string, val: any) => {
          b._where.push({ col, op, val });
          return b;
        },
        execute: () => {
          const idWhere = b._where.find((w: any) => w.col === 'id');
          const empWhere = b._where.find((w: any) => w.col === 'employee_id');
          if (table === 'core.onboarding_candidates' && idWhere) {
            const target = candidatesStore.find((x) => x.id === idWhere.val);
            if (target) Object.assign(target, b._set);
          }
          if (table === 'core.employees') {
            const target = employeesStore.find((x) => x.id === (idWhere?.val ?? empWhere?.val));
            if (target) Object.assign(target, b._set);
          }
          if (table === 'core.onboarding_tasks') {
            const taskCodeWhere = b._where.find((w: any) => w.col === 'task_code');
            const matchingTasks = tasksStore.filter((x) => {
              if (idWhere && x.id !== idWhere.val) return false;
              if (empWhere && x.employee_id !== empWhere.val) return false;
              if (taskCodeWhere && x.task_code !== taskCodeWhere.val) return false;
              return true;
            });
            for (const t of matchingTasks) {
              Object.assign(t, b._set);
            }
          }
          if (table === 'core.probation_reviews' && idWhere) {
            const target = reviewsStore.find((x) => x.id === idWhere.val);
            if (target) Object.assign(target, b._set);
          }
          if (table === 'pay.employee_salaries' && empWhere) {
            const target = salariesStore.find((x) => x.employee_id === empWhere.val);
            if (target) Object.assign(target, b._set);
          }
          if (table === 'core.companies' && companiesStore[0]) {
            Object.assign(companiesStore[0], b._set);
          }
          return Promise.resolve();
        },
      };
      return b;
    },
  } as unknown as Kysely<Database>;

  describe('LC-01 — Pre-join Tokens & Candidate Intake', () => {
    it('generates a 72-hour secure token with SHA-256 hash', () => {
      const token = PrejoinService.generateToken();

      expect(token.rawToken.length).toBe(64); // 32 bytes hex
      expect(token.tokenHash.length).toBe(64); // SHA-256 hex
      expect(token.expiresAt.getTime()).toBeGreaterThan(Date.now() + 71 * 60 * 60 * 1000);
      expect(token.expiresAt.getTime()).toBeLessThanOrEqual(Date.now() + 72 * 60 * 60 * 1000 + 1000);
    });

    it('ingests candidate from ATS and tracks prejoin token', async () => {
      const input: IngestCandidateInput = {
        fullName: 'Rahul Sen',
        personalEmail: 'rahul.sen@example.com',
        mobile: '9876543210',
        positionTitle: 'Junior Metallurgist',
        offeredCtc: 450000,
        probationMonths: 6,
        probationSalaryPct: 90,
        proposedDoj: '2026-08-01',
        offerDate: '2026-07-15',
        companyId: 1,
      };

      const res = await OnboardingService.ingestCandidate(mockDb, input);

      expect(res.candidateId).toBeDefined();
      expect(res.rawToken).toBeDefined();

      const saved = candidatesStore.find((c) => c.id === res.candidateId);
      expect(saved).toBeDefined();
      expect(saved.full_name).toBe('Rahul Sen');
      expect(saved.status).toBe('link_sent');
    });

    it('submits pre-join profile and statutory information', async () => {
      const candidate = candidatesStore[0];
      expect(candidate).toBeDefined();

      const submission: PrejoinSubmissionData = {
        presentAddress: 'Kharagpur Steel Township, Sector 4',
        permanentAddress: 'Kolkata, Salt Lake Block B',
        emergencyContactName: 'Bina Sen',
        emergencyContactPhone: '9876543211',
        emergencyContactRelation: 'Mother',
        pan: 'ABCPS1234F',
        aadhaar: '123456789012',
        bankName: 'State Bank of India',
        bankAccount: '12345678901',
        bankIfsc: 'SBIN0001234',
        bloodGroup: 'B+',
      };

      const result = await PrejoinService.submitPrejoinData(
        mockDb,
        candidate.prejoin_link_token,
        submission
      );

      expect(result.success).toBe(true);
      expect(candidate.status).toBe('prejoin_done');
      expect(candidate.prejoin_completed_at).toBeDefined();
    });

    it('rejects expired pre-join tokens', async () => {
      // Create candidate with expired token
      const expiredCandidateId = 9999;
      candidatesStore.push({
        id: expiredCandidateId,
        prejoin_token_hash: 'expired_hash_123',
        prejoin_token_expires_at: new Date(Date.now() - 1000).toISOString(), // expired in past
        status: 'link_sent',
      });

      // Validating an expired token should fail
      const check = await PrejoinService.validateToken(mockDb, 'any_token');
      expect(check.isValid).toBe(false);
    });
  });

  describe('LC-01 — Duplicate Detection', () => {
    it('detects duplicate employees based on mobile or email', async () => {
      employeesStore.push({
        id: 1,
        ecode: 'RML000100',
        first_name: 'Existing',
        last_name: 'User',
        personal_email: 'existing.user@example.com',
        work_email: 'rml000100@rashmigroup.com',
        mobile: '9876500000',
        pan: 'EXTPAN1234',
      });

      const emailDup = await OnboardingService.checkDuplicate(
        mockDb,
        'existing.user@example.com',
        '9999999999'
      );
      expect(emailDup.hasDuplicate).toBe(true);
      expect(emailDup.duplicateField).toBe('email');
      expect(emailDup.existingEcode).toBe('RML000100');

      const mobileDup = await OnboardingService.checkDuplicate(
        mockDb,
        'new@example.com',
        '9876500000'
      );
      expect(mobileDup.hasDuplicate).toBe(true);
      expect(mobileDup.duplicateField).toBe('mobile');

      const noDup = await OnboardingService.checkDuplicate(
        mockDb,
        'unique@example.com',
        '9111111111'
      );
      expect(noDup.hasDuplicate).toBe(false);
    });
  });

  describe('LC-01 & LC-02 — HR Conversion Wizard & Stakeholder Fan-out', () => {
    it('converts candidate to employee, generates e-code, and fans out tasks', async () => {
      const candidate = candidatesStore[0];
      expect(candidate).toBeDefined();

      const convertInput: ConvertCandidateInput = {
        candidateId: candidate.id,
        companyId: 1,
        designationId: 10,
        departmentId: 5,
        locationId: 2,
        doj: '2026-08-01',
        salaryStructureId: 100,
      };

      const result = await OnboardingService.convertCandidate(mockDb, convertInput);

      expect(result.employeeId).toBeDefined();
      expect(result.ecode).toMatch(/^RML\d{6}$/);

      // Verify employee record created
      const emp = employeesStore.find((e) => e.id === result.employeeId);
      expect(emp).toBeDefined();
      expect(emp.ecode).toBe(result.ecode);
      expect(emp.first_name).toBe('Rahul');
      expect(emp.contract_type).toBe('probationary');
      expect(emp.biometric_registered).toBe(false);

      // Verify user login created
      const user = usersStore.find((u) => u.employee_id === result.employeeId);
      expect(user).toBeDefined();

      // Verify probation salary assignment (90% of ₹4,50,000 = ₹4,05,000)
      const salary = salariesStore.find((s) => s.employee_id === result.employeeId);
      expect(salary).toBeDefined();
      expect(Number(salary.annual_ctc)).toBe(405000);

      // Verify candidate status updated
      expect(candidate.status).toBe('converted');

      // Verify fan-out stakeholder tasks (5 standard tasks)
      const empTasks = tasksStore.filter((t) => t.employee_id === result.employeeId);
      expect(empTasks.length).toBe(5);
      expect(empTasks.some((t) => t.task_code === 'it_email')).toBe(true);
      expect(empTasks.some((t) => t.task_code === 'it_biometric')).toBe(true);

      // Verify initial probation review created with due date 6 months after DOJ
      const review = reviewsStore.find((r) => r.employee_id === result.employeeId);
      expect(review).toBeDefined();
      expect(review.status).toBe('pending');
      expect(new Date(review.due_date).toISOString().slice(0, 10)).toBe('2027-02-01');
    });

    it('handles Kent biometric verification and completes biometric task', async () => {
      const emp = employeesStore[employeesStore.length - 1];
      expect(emp).toBeDefined();

      await TaskFanoutService.verifyBiometricRegistration(mockDb, emp.id, 1);

      expect(emp.biometric_registered).toBe(true);
      const bioTask = tasksStore.find(
        (t) => t.employee_id === emp.id && t.task_code === 'it_biometric'
      );
      expect(bioTask?.status).toBe('completed');
    });

    it('escalates overdue stakeholder tasks past SLA due date', async () => {
      // Add a task due in the past
      tasksStore.push({
        id: 8888,
        employee_id: 1,
        task_code: 'admin_id_card',
        task_name: 'Print ID Card',
        status: 'open',
        due_date: '2026-07-01', // in past
      });

      const escalatedCount = await TaskFanoutService.checkTaskEscalations(
        mockDb,
        new Date('2026-08-01')
      );

      expect(escalatedCount).toBeGreaterThan(0);
      const overdueTask = tasksStore.find((t) => t.id === 8888);
      expect(overdueTask?.status).toBe('escalated');
      expect(overdueTask?.escalated_at).toBeDefined();
    });
  });

  describe('LC-04 — Probation Board & Confirmation Engine', () => {
    it('submits manager evaluation for probation review', async () => {
      const review = reviewsStore[0];
      expect(review).toBeDefined();

      await ProbationService.submitEvaluation(mockDb, {
        reviewId: review.id,
        managerRecommendation: 'confirm',
        reviewNotes: 'Excellent performance during probation in rolling mill.',
        ratings: { technical: 5, safety: 5, punctuality: 4 },
      });

      expect(review.manager_recommendation).toBe('confirm');
      expect(review.status).toBe('under_review');
    });

    it('confirms employee, transitions to 100% CTC, and enqueues confirmation letter', async () => {
      const review = reviewsStore[0];
      const empId = review.employee_id;

      const decision = await ProbationService.decideReview(mockDb, {
        reviewId: review.id,
        outcome: 'confirmed',
        decidedByUserId: 1,
        confirmationDate: '2027-02-01',
        confirmedAnnualCtc: 450000, // 100% full CTC
        salaryStructureId: 100,
        decisionNotes: 'Confirmed by Plant Head & HR Head.',
      });

      expect(decision.outcome).toBe('confirmed');
      expect(decision.confirmationLetterId).toBeDefined();

      // Check review outcome
      expect(review.outcome).toBe('confirmed');
      expect(review.status).toBe('completed');
      expect(new Date(review.confirmation_date).toISOString().slice(0, 10)).toBe('2027-02-01');

      // Check employee status advanced to permanent
      const emp = employeesStore.find((e) => e.id === empId);
      expect(emp?.contract_type).toBe('permanent');

      // Check new confirmed salary row with 100% CTC
      const newSalary = salariesStore[salariesStore.length - 1];
      expect(Number(newSalary.annual_ctc)).toBe(450000);
      expect(new Date(newSalary.effective_from).toISOString().slice(0, 10)).toBe('2027-02-01');

      // Check confirmation letter created
      const letter = lettersStore.find((l) => l.employee_id === empId);
      expect(letter).toBeDefined();
      expect(letter.template_code).toBe('CONFIRMATION_LETTER');
    });

    it('supports probation extension and triggers next review cycle', async () => {
      // Add new probation review to test extension
      const reviewToExtend: Record<string, unknown> = {
        id: 7777,
        employee_id: 2,
        due_date: '2026-09-01',
        status: 'under_review',
        manager_recommendation: 'extend',
        extension_months: 2,
      };
      reviewsStore.push(reviewToExtend);

      const decision = await ProbationService.decideReview(mockDb, {
        reviewId: 7777,
        outcome: 'extended',
        decidedByUserId: 1,
        extensionMonths: 2,
        decisionNotes: 'Probation extended by 2 months for additional training.',
      });

      expect(decision.outcome).toBe('extended');
      expect(reviewToExtend['outcome']).toBe('extended');
      expect(reviewToExtend['status']).toBe('completed');

      // Check new subsequent review created with extended due date
      const nextReview = reviewsStore.find(
        (r) => r.employee_id === 2 && r.status === 'pending'
      );
      expect(nextReview).toBeDefined();
      expect(new Date(nextReview.due_date).toISOString().slice(0, 10)).toBe('2026-11-01');
    });

    it('identifies upcoming probation due reviews for reminder alerts', async () => {
      reviewsStore.push({
        id: 5001,
        employee_id: 10,
        due_date: '2026-08-31', // exactly 30 days from 2026-08-01
        status: 'pending',
      });
      reviewsStore.push({
        id: 5002,
        employee_id: 11,
        due_date: '2026-08-15', // exactly 14 days from 2026-08-01
        status: 'pending',
      });

      const alerts = await ProbationService.getUpcomingProbationAlerts(
        mockDb,
        new Date('2026-08-01')
      );

      expect(alerts.d30).toContain(5001);
      expect(alerts.d14).toContain(5002);
    });
  });
});
