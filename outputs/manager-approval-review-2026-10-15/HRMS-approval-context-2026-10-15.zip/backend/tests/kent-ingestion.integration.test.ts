/**
 * Stage 0.6 spike (P0-T40 with the MOCK connector — real Kent swaps in later):
 * one simulated day flows end-to-end into partitioned att.swipe_events;
 * re-ingestion is a no-op (idempotent); raw rows are immutable; a silent
 * door is detected (the PP-9 drill); FILO aggregation works.
 */
import 'dotenv/config';
import { afterAll, beforeAll, describe, expect, it } from 'vitest';
import { sql, type Kysely } from 'kysely';
import { createDatabase } from '../src/core/db/database.js';
import type { Database } from '../src/core/db/types.js';
import { findSilentDevices, ingestOnce, MockKentConnector } from '../src/modules/attendance/index.js';

const DB_URL = process.env['DATABASE_URL'];
const run = describe.skipIf(!DB_URL);

const SOURCE = 'mock-kent-test';

run('mock Kent ingestion spike (live Postgres)', () => {
  let db: Kysely<Database>;
  let employeeNos: string[];
  // Raw swipes are immutable (can't be cleaned up between runs), so each run
  // simulates a UNIQUE day — idempotency is still proven by re-ingesting the
  // same connector within the run. Partition auto-creation covers any month.
  // Anchored AFTER the ingestion epoch (2020) so the watermark never filters it.
  const day = new Date(Date.UTC(2030, 0, 1) + (Date.now() % 20_000) * 86_400_000);

  beforeAll(async () => {
    db = createDatabase(DB_URL ?? '');
    // Employees from the Stage-0.5 import (falls back to synthetic if absent).
    const rows = await db.selectFrom('core.employees').select('ecode').limit(20).execute();
    employeeNos = rows.length > 0 ? rows.map((r) => r.ecode) : ['RML000001', 'RML035384'];

    await db.deleteFrom('att.ingest_watermarks').where('source', '=', SOURCE).execute();
    await sql`DELETE FROM att.swipe_events WHERE source = ${SOURCE}`.execute(db).catch(() => {
      /* immutable trigger blocks DELETE — clean via partition detach is a Phase-1 op; use unique day instead */
    });
  });

  afterAll(async () => {
    await db.destroy();
  });

  it('ingests one simulated day end-to-end, then re-ingests with ZERO duplicates', async () => {
    const connector = new MockKentConnector({ employeeNos, day, seed: 7 });

    const first = await ingestOnce(db, connector, SOURCE);
    expect(first.fetched).toBeGreaterThanOrEqual(employeeNos.length * 2);
    expect(first.inserted).toBeGreaterThan(0);
    expect(first.unmatchedEmployeeNos).toHaveLength(0); // all e-codes resolved to employees

    // Watermark advanced → same connector now yields nothing new.
    const second = await ingestOnce(db, connector, SOURCE);
    expect(second.inserted).toBe(0);

    // Even a FULL replay (watermark reset) inserts nothing — the DB key dedupes.
    await db.deleteFrom('att.ingest_watermarks').where('source', '=', SOURCE).execute();
    const replay = await ingestOnce(db, connector, SOURCE);
    expect(replay.fetched).toBe(first.fetched);
    expect(replay.inserted).toBe(0);
  });

  it('raw swipes are immutable at the database layer', async () => {
    await expect(
      sql`UPDATE att.swipe_events SET direction = 'out' WHERE source = ${SOURCE}`.execute(db),
    ).rejects.toThrow(/append-only/);
  });

  it('unknown employee_no is kept with employee_id NULL — the exception queue, never dropped', async () => {
    // PER-RUN source → fresh watermark every time. (A persistent ghost
    // watermark + non-monotonic random days filtered everything on some runs.)
    const ghost = new MockKentConnector({ employeeNos: ['ZZZ999999'], day, seed: 8 });
    const result = await ingestOnce(db, ghost, `ghost-${Date.now()}`);
    expect(result.unmatchedEmployeeNos).toContain('ZZZ999999');

    const row = await db
      .selectFrom('att.swipe_events')
      .select(['employee_id', 'employee_no'])
      .where('employee_no', '=', 'ZZZ999999')
      .executeTakeFirstOrThrow();
    expect(row.employee_id).toBeNull();
  });

  it('detects a silent door (the PP-9 drill): offline device shows up on the health board', async () => {
    // Dedicated door for this run (the four shared mock doors are touched by
    // other suites whose last_seen only moves forward — order-independent this way).
    const drillDoor = `PP9-Drill-${Date.now()}`;
    await db
      .insertInto('att.devices')
      .values({ door_code: drillDoor, source: SOURCE, last_seen_at: new Date(day.getTime() + 18 * 3600_000) })
      .execute();

    const silent = await findSilentDevices(db, new Date(day.getTime() + 42 * 3600_000), 60);
    expect(silent.some((d) => d.doorCode === drillDoor)).toBe(true);

    await db.deleteFrom('att.devices').where('door_code', '=', drillDoor).execute();
  });

  it('FILO first-in/last-out aggregates cleanly from raw swipes (Phase-1 processor input)', async () => {
    const rows = await sql<{ employee_no: string; first_in: Date; last_out: Date }>`
      SELECT employee_no, MIN(swipe_ts) AS first_in, MAX(swipe_ts) AS last_out
      FROM att.swipe_events
      WHERE source = ${SOURCE} AND employee_id IS NOT NULL
      GROUP BY employee_no
    `.execute(db);
    expect(rows.rows.length).toBeGreaterThanOrEqual(employeeNos.length);
    for (const r of rows.rows) {
      expect(r.first_in.getTime()).toBeLessThan(r.last_out.getTime());
    }
  });
});
