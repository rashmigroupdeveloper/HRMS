/**
 * Employees read API — directory + profile shell (P0-T33 / CORE-01, docs/05 §4.2).
 * Guarded by `employee.read`. Statutory fields masked in the service layer.
 */
import { ORPCError } from '@orpc/server';
import { z } from 'zod';
import { withPermission } from '../../api/orpc.js';
import { booleanQuery, csvList } from '../../api/zod.js';
import {
  getEmployeeByEcode,
  getOwnProfile,
  listDirectoryFacets,
  listEmployees,
} from './employees.service.js';

const guard = () => withPermission('employee.read');

const directoryItem = z.object({
  ecode: z.string(),
  name: z.string(),
  designation: z.string().nullable(),
  department: z.string().nullable(),
  entity: z.string(),
  entityName: z.string(),
  status: z.string(),
  statusLabel: z.string(),
});

const listProcedure = guard()
  .route({
    method: 'GET',
    path: '/employees',
    summary: 'Employee directory (filterable, paginated)',
  })
  .input(
    z
      .object({
        q: z.string().optional(),
        companyCode: z.string().optional(),
        status: z.enum(['onboarding', 'active', 'on_notice', 'exited']).optional(),
        // docs/05 §4.2 filter set — every facet the drawer offers is applied
        // here. Multi-valued, because the drawer offers multi-select: a
        // single-valued filter would silently drop the second selection.
        companyCodes: csvList(z.string()).optional(),
        statuses: csvList(z.enum(['onboarding', 'active', 'on_notice', 'exited'])).optional(),
        departmentIds: csvList(z.coerce.number().int().positive()).optional(),
        locationIds: csvList(z.coerce.number().int().positive()).optional(),
        categories: csvList(
          z.enum(['white_collar', 'blue_collar', 'trainee', 'consultant', 'contract']),
        ).optional(),
        reportingManagerId: z.coerce.number().int().positive().optional(),
        activeOnly: booleanQuery().optional(),
        page: z.coerce.number().int().min(1).optional(),
        pageSize: z.coerce.number().int().min(1).max(200).optional(),
      })
      .optional(),
  )
  .output(
    z.object({
      items: z.array(directoryItem),
      total: z.number().int(),
      page: z.number().int(),
      pageSize: z.number().int(),
    }),
  )
  .handler(async ({ input, context }) => {
    const scope = {
      ...context.permissionAccess,
      actorEmployeeId: context.user.employee_id,
    };
    return listEmployees(context.db, input ?? {}, scope);
  });

const profileOutput = z.object({
  ecode: z.string(),
  name: z.string(),
  photoPath: z.string().nullable(),
  gender: z.string().nullable(),
  dob: z.string().nullable(),
  maritalStatus: z.string().nullable(),
  bloodGroup: z.string().nullable(),
  personalEmail: z.string().nullable(),
  workEmail: z.string().nullable(),
  mobile: z.string().nullable(),
  emergencyContactName: z.string().nullable(),
  emergencyContactPhone: z.string().nullable(),
  presentAddress: z.string().nullable(),
  permanentAddress: z.string().nullable(),
  category: z.string().nullable(),
  contractType: z.string().nullable(),
  doj: z.string().nullable(),
  dol: z.string().nullable(),
  status: z.string(),
  statusLabel: z.string(),
  exitReason: z.string().nullable(),
  confirmationDate: z.string().nullable(),
  probationDueDate: z.string().nullable(),
  entity: z.string(),
  entityName: z.string(),
  designation: z.string().nullable(),
  department: z.string().nullable(),
  locationName: z.string().nullable(),
  gradeName: z.string().nullable(),
  reportingManagerEcode: z.string().nullable(),
  reportingManagerName: z.string().nullable(),
  statutoryMasked: z.boolean(),
  pan: z.string().nullable(),
  aadhaar: z.string().nullable(),
  uan: z.string().nullable(),
  pfNumber: z.string().nullable(),
  esicIpNumber: z.string().nullable(),
  bankName: z.string().nullable(),
  bankAccount: z.string().nullable(),
  bankIfsc: z.string().nullable(),
  paymentMode: z.string(),
  canViewCompensation: z.boolean(),
});

const getOwnProcedure = guard()
  .route({
    method: 'GET',
    path: '/employees/me',
    summary: 'The signed-in user’s own employee profile (self-service; statutory permission-masked)',
  })
  .output(profileOutput)
  .handler(async ({ context }) => {
    const profile = await getOwnProfile(context.db, context.user, context.permissions);
    if (!profile) {
      throw new ORPCError('NOT_FOUND', {
        message: 'No employee profile is linked to your account',
      });
    }
    return profile;
  });

const getByEcodeProcedure = guard()
  .route({
    method: 'GET',
    path: '/employees/{ecode}',
    summary: 'Employee profile by e-code (statutory fields permission-masked)',
  })
  .input(z.object({ ecode: z.string().min(3).max(32) }))
  .output(profileOutput)
  .handler(async ({ input, context }) => {
    const scope = {
      ...context.permissionAccess,
      actorEmployeeId: context.user.employee_id,
    };
    const profile = await getEmployeeByEcode(
      context.db,
      input.ecode,
      context.user,
      context.permissions,
      scope,
    );
    if (!profile) {
      throw new ORPCError('NOT_FOUND', { message: `Employee ${input.ecode} not found` });
    }
    return profile;
  });

const facetGroup = z.array(z.object({ code: z.string(), label: z.string(), count: z.number() }));

/**
 * Real filter facets for the directory (docs/05 §4.2: "filters: entity, plant,
 * dept, category, status, RM"). Counts are DERIVED from the master — the
 * filter drawer must never author a headcount of its own.
 */
const facetsProcedure = guard()
  .route({
    method: 'GET',
    path: '/employees/facets',
    summary: 'Directory filter facets with live counts',
  })
  .input(z.object({ activeOnly: booleanQuery().optional() }).optional())
  .output(
    z.object({
      entities: facetGroup,
      departments: facetGroup,
      categories: facetGroup,
      locations: facetGroup,
      statuses: facetGroup,
      total: z.number(),
    }),
  )
  .handler(async ({ input, context }) => {
    const scope = {
      ...context.permissionAccess,
      actorEmployeeId: context.user.employee_id,
    };
    return listDirectoryFacets(context.db, { activeOnly: input?.activeOnly }, scope);
  });

export const employeesRouter = {
  list: listProcedure,
  facets: facetsProcedure,
  getOwn: getOwnProcedure,
  getByEcode: getByEcodeProcedure,
};
