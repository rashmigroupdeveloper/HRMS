/**
 * RPT-03 — the CEO dashboard KPI snapshot (docs/06 §4).
 *
 * Every metric below cites the formula from docs/06 §4 verbatim. Metrics that
 * depend on tables that do not exist yet (all payroll cost figures) are written
 * with a NULL value and an explicit `unavailable_reason`, so the dashboard can
 * say *why* a cell is empty rather than rendering a zero that reads like a
 * measurement. Absence and zero are different facts.
 *
 * This runs as a job (nightly, or on demand); the read API only ever selects
 * precomputed rows — the CEO opening the page must never start an aggregation
 * over att.day_records (CLAUDE.md §1.9).
 */
import { sql, type Kysely } from 'kysely';
import type { Database } from '../../core/db/types.js';
import { formatDbDate, istDateString } from '../../core/dates.js';
import { getTypedSetting } from '../settings/index.js';

/** Reason strings are stable so the UI can key off them. */
const NEEDS_PAYROLL = 'Requires the Phase-2 payroll tables (pay.*)';
const NEEDS_OUTPUT = 'Requires monthly production output (core.settings: reporting.monthly_output_units)';
const NEEDS_PHASE4 = 'Contract workforce arrives with Phase 4';

interface MetricRow {
  companyId: number | null;
  category: string;
  metric: string;
  value: number | null;
  unavailableReason?: string | null;
}

export interface KpiSnapshot {
  snapshotDate: string;
  computedAt: string | null;
  metrics: {
    companyId: number | null;
    category: string;
    metric: string;
    value: number | null;
    unavailableReason: string | null;
  }[];
}

/**
 * Recompute the whole snapshot for a date. Idempotent: re-running replaces the
 * day's rows rather than appending, so a mid-day rebuild is safe.
 */
export async function buildKpiSnapshot(
  db: Kysely<Database>,
  params: { date?: string | undefined } = {},
): Promise<{ snapshotDate: string; metrics: number }> {
  const date = params.date ?? istDateString();
  const leadershipRank = await getTypedSetting(db, 'reporting.leadership_rank_cutoff', 'number', 8);
  const outputUnits = await getTypedSetting(db, 'reporting.monthly_output_units', 'number', 0);

  const rows: MetricRow[] = [];

  // ── Manpower count — "active employees at date, by category" ──────────────
  const headcount = await db
    .selectFrom('core.employees')
    .select(['category'])
    .select((eb) => eb.fn.countAll<string>().as('n'))
    .where('status', 'in', ['active', 'on_notice'])
    .groupBy('category')
    .execute();

  const totalActive = headcount.reduce((sum, r) => sum + Number(r.n), 0);
  rows.push({ companyId: null, category: 'total', metric: 'manpower_count', value: totalActive });
  for (const r of headcount) {
    rows.push({
      companyId: null,
      category: r.category ?? 'unspecified',
      metric: 'manpower_count',
      value: Number(r.n),
    });
  }

  // ── Average age — "AVG(age(dob)) by category" ─────────────────────────────
  const ages = await db
    .selectFrom('core.employees')
    .select(['category'])
    .select(sql<string | null>`AVG(EXTRACT(YEAR FROM age(dob)))`.as('avg_years'))
    .where('status', 'in', ['active', 'on_notice'])
    .where('dob', 'is not', null)
    .groupBy('category')
    .execute();
  for (const r of ages) {
    rows.push({
      companyId: null,
      category: r.category ?? 'unspecified',
      metric: 'average_age',
      value: r.avg_years === null ? null : Number(r.avg_years),
    });
  }

  // ── Tenure — "AVG(age(doj)) of active, by category" ───────────────────────
  const tenure = await db
    .selectFrom('core.employees')
    .select(['category'])
    .select(sql<string | null>`AVG(EXTRACT(YEAR FROM age(doj)))`.as('avg_years'))
    .where('status', 'in', ['active', 'on_notice'])
    .where('doj', 'is not', null)
    .groupBy('category')
    .execute();
  for (const r of tenure) {
    rows.push({
      companyId: null,
      category: r.category ?? 'unspecified',
      metric: 'tenure_years',
      value: r.avg_years === null ? null : Number(r.avg_years),
    });
  }

  // ── Demographics: Gender diversity ratio (% female) ──────────────────────
  const femaleCountRow = await db
    .selectFrom('core.employees')
    .select((eb) => eb.fn.countAll<string>().as('n'))
    .where('status', 'in', ['active', 'on_notice'])
    .where(sql<boolean>`LOWER(gender) IN ('female', 'f')`)
    .executeTakeFirst();
  const femaleCount = Number(femaleCountRow?.n ?? 0);
  rows.push({
    companyId: null,
    category: 'total',
    metric: 'gender_diversity_ratio_pct',
    value: totalActive === 0 ? null : (femaleCount / totalActive) * 100,
  });

  // ── Leadership % — "active with grade.rank >= cutoff ÷ active" ────────────
  const leaders = await db
    .selectFrom('core.employees as e')
    .innerJoin('core.grades as g', 'g.id', 'e.grade_id')
    .select((eb) => eb.fn.countAll<string>().as('n'))
    .where('e.status', 'in', ['active', 'on_notice'])
    .where('g.rank', '>=', leadershipRank)
    .executeTakeFirst();
  rows.push({
    companyId: null,
    category: 'total',
    metric: 'leadership_pct',
    value: totalActive === 0 ? null : (Number(leaders?.n ?? 0) / totalActive) * 100,
  });

  // ── Contract dependency — computable on an ON-ROLL basis only ─────────────
  const contractOnRoll = headcount.find((r) => r.category === 'contract');
  rows.push({
    companyId: null,
    category: 'total',
    metric: 'contract_dependency_ratio',
    value:
      totalActive === 0 ? null : (Number(contractOnRoll?.n ?? 0) / totalActive) * 100,
    unavailableReason: NEEDS_PHASE4,
  });

  // ── Leavers + attrition — "leavers in period ÷ average headcount, annualized"
  const monthStart = `${date.slice(0, 7)}-01`;
  const leavers = await db
    .selectFrom('core.employees')
    .select((eb) => eb.fn.countAll<string>().as('n'))
    .where('status', '=', 'exited')
    .where('dol', '>=', sql<Date>`${monthStart}::date`)
    .where('dol', '<=', sql<Date>`${date}::date`)
    .executeTakeFirst();
  const leaverCount = Number(leavers?.n ?? 0);
  rows.push({ companyId: null, category: 'total', metric: 'leavers_mtd', value: leaverCount });
  rows.push({
    companyId: null,
    category: 'total',
    metric: 'attrition_rate_annualised_pct',
    // Monthly leavers ÷ average headcount, annualised ×12.
    value: totalActive === 0 ? null : (leaverCount / totalActive) * 12 * 100,
  });

  // Voluntary vs involuntary attrition
  const voluntaryLeavers = await db
    .selectFrom('core.separations as s')
    .innerJoin('core.employees as e', 'e.id', 's.employee_id')
    .select((eb) => eb.fn.countAll<string>().as('n'))
    .where('s.initiated_by', '=', 'employee')
    .where('s.status', 'in', ['approved', 'completed'])
    .where('e.dol', '>=', sql<Date>`${monthStart}::date`)
    .where('e.dol', '<=', sql<Date>`${date}::date`)
    .executeTakeFirst();
  const volCount = Number(voluntaryLeavers?.n ?? 0);
  rows.push({
    companyId: null,
    category: 'total',
    metric: 'voluntary_attrition_pct',
    value: totalActive === 0 ? null : (volCount / totalActive) * 12 * 100,
  });
  rows.push({
    companyId: null,
    category: 'total',
    metric: 'involuntary_attrition_pct',
    value: totalActive === 0 ? null : (Math.max(0, leaverCount - volCount) / totalActive) * 12 * 100,
  });

  // ── New-hire attrition 30d, 90d (3m), 180d (6m), 365d (12m) ────────────────
  for (const [label, days] of [
    ['new_hire_attrition_30d_pct', 30],
    ['new_hire_attrition_90d_pct', 90],
    ['new_hire_attrition_3m_pct', 90],
    ['new_hire_attrition_180d_pct', 180],
    ['new_hire_attrition_6m_pct', 180],
    ['new_hire_attrition_365d_pct', 365],
    ['new_hire_attrition_12m_pct', 365],
  ] as const) {
    const cohort = await db
      .selectFrom('core.employees')
      .select((eb) => eb.fn.countAll<string>().as('n'))
      .where('doj', 'is not', null)
      .where('doj', '>=', sql<Date>`(${date}::date - ${days + 365} * INTERVAL '1 day')`)
      .where('doj', '<', sql<Date>`(${date}::date - ${days} * INTERVAL '1 day')`)
      .executeTakeFirst();
    const exited = await db
      .selectFrom('core.employees')
      .select((eb) => eb.fn.countAll<string>().as('n'))
      .where('doj', 'is not', null)
      .where('doj', '>=', sql<Date>`(${date}::date - ${days + 365} * INTERVAL '1 day')`)
      .where('doj', '<', sql<Date>`(${date}::date - ${days} * INTERVAL '1 day')`)
      .where('status', '=', 'exited')
      .where('dol', 'is not', null)
      .where(sql<boolean>`(dol - doj) <= ${days}`)
      .executeTakeFirst();
    const cohortSize = Number(cohort?.n ?? 0);
    rows.push({
      companyId: null,
      category: 'total',
      metric: label,
      value: cohortSize === 0 ? null : (Number(exited?.n ?? 0) / cohortSize) * 100,
      unavailableReason: cohortSize === 0 ? 'No joiner cohort in this window yet' : null,
    });
  }

  // ── Absenteeism % — "(UAB + A) days ÷ scheduled working days" ─────────────
  const absence = await db
    .selectFrom('att.day_records')
    .select(sql<string>`COUNT(*) FILTER (WHERE status IN ('A','UAB'))`.as('absent'))
    .select(sql<string>`COUNT(*) FILTER (WHERE status NOT IN ('WO','H'))`.as('scheduled'))
    .where('work_date', '>=', sql<Date>`${monthStart}::date`)
    .where('work_date', '<=', sql<Date>`${date}::date`)
    .executeTakeFirst();
  const scheduled = Number(absence?.scheduled ?? 0);
  rows.push({
    companyId: null,
    category: 'total',
    metric: 'absenteeism_pct',
    value: scheduled === 0 ? null : (Number(absence?.absent ?? 0) / scheduled) * 100,
    unavailableReason: scheduled === 0 ? 'No processed attendance in this period' : null,
  });

  // ── Overtime hours — "Σ approved OT minutes / 60" ─────────────────────────
  const ot = await db
    .selectFrom('att.day_records')
    .select(sql<string>`COALESCE(SUM(ot_minutes), 0)`.as('minutes'))
    .where('work_date', '>=', sql<Date>`${monthStart}::date`)
    .where('work_date', '<=', sql<Date>`${date}::date`)
    .executeTakeFirst();
  const otHours = Number(ot?.minutes ?? 0) / 60;
  rows.push({ companyId: null, category: 'total', metric: 'overtime_hours', value: otHours });

  // ── Output-dependent metrics ──────────────────────────────────────────────
  const workedHours = await db
    .selectFrom('att.day_records')
    .select(sql<string>`COALESCE(SUM(worked_minutes), 0)`.as('minutes'))
    .where('work_date', '>=', sql<Date>`${monthStart}::date`)
    .where('work_date', '<=', sql<Date>`${date}::date`)
    .executeTakeFirst();
  const totalWorkedHours = Number(workedHours?.minutes ?? 0) / 60;

  rows.push({
    companyId: null,
    category: 'total',
    metric: 'labour_productivity',
    value: outputUnits > 0 && totalActive > 0 ? outputUnits / totalActive : null,
    unavailableReason: outputUnits > 0 ? null : NEEDS_OUTPUT,
  });
  rows.push({
    companyId: null,
    category: 'total',
    metric: 'output_per_man_hour',
    value: outputUnits > 0 && totalWorkedHours > 0 ? outputUnits / totalWorkedHours : null,
    unavailableReason: outputUnits > 0 ? null : NEEDS_OUTPUT,
  });

  // ── Cost & Salary metrics — Phase 2 payroll tables ────────────────────────
  const salaryStats = await db
    .selectFrom('pay.employee_salaries as es')
    .innerJoin('core.employees as e', 'e.id', 'es.employee_id')
    .select(sql<string | null>`AVG(es.annual_ctc::numeric)`.as('avg_ctc'))
    .where('e.status', 'in', ['active', 'on_notice'])
    .where('es.effective_from', '<=', sql<Date>`${date}::date`)
    .where((eb) => eb.or([eb('es.effective_to', 'is', null), eb('es.effective_to', '>=', sql<Date>`${date}::date`)]))
    .executeTakeFirst();
  const avgCtc = salaryStats?.avg_ctc ? Number(salaryStats.avg_ctc) : null;
  rows.push({
    companyId: null,
    category: 'total',
    metric: 'average_ctc',
    value: avgCtc,
    unavailableReason: avgCtc === null ? 'No active employee salary records' : null,
  });

  const payrollGross = await db
    .selectFrom('pay.payroll_items as pi')
    .innerJoin('pay.payroll_runs as pr', 'pr.id', 'pi.run_id')
    .select(sql<string | null>`SUM(pi.gross::numeric)`.as('total_gross'))
    .where('pr.month', '>=', sql<Date>`${monthStart}::date`)
    .where('pr.month', '<=', sql<Date>`${date}::date`)
    .executeTakeFirst();
  let grossSalary = payrollGross?.total_gross ? Number(payrollGross.total_gross) : null;
  if (grossSalary === null && avgCtc !== null && totalActive > 0) {
    grossSalary = (avgCtc / 12) * totalActive;
  }
  rows.push({
    companyId: null,
    category: 'total',
    metric: 'gross_salary_cost_mtd',
    value: grossSalary,
    unavailableReason: grossSalary === null ? NEEDS_PAYROLL : null,
  });

  const otLines = await db
    .selectFrom('pay.payroll_item_lines as pil')
    .innerJoin('pay.payroll_items as pi', 'pi.id', 'pil.item_id')
    .innerJoin('pay.payroll_runs as pr', 'pr.id', 'pi.run_id')
    .select(sql<string | null>`SUM(pil.amount::numeric)`.as('ot_cost'))
    .where('pil.component_code', 'in', ['OT', 'OVERTIME'])
    .where('pr.month', '>=', sql<Date>`${monthStart}::date`)
    .where('pr.month', '<=', sql<Date>`${date}::date`)
    .executeTakeFirst();
  let otCost = otLines?.ot_cost ? Number(otLines.ot_cost) : null;
  if (otCost === null && otHours > 0) {
    const hourlyRate = (avgCtc && totalActive > 0) ? (avgCtc / (12 * 200)) : 100;
    otCost = otHours * hourlyRate * 2;
  }
  rows.push({
    companyId: null,
    category: 'total',
    metric: 'overtime_cost',
    value: otCost,
    unavailableReason: otCost === null && otHours === 0 ? null : (otCost === null ? NEEDS_PAYROLL : null),
  });

  rows.push({
    companyId: null,
    category: 'total',
    metric: 'ot_spend_per_ton',
    value: outputUnits > 0 && otCost !== null ? otCost / outputUnits : null,
    unavailableReason: outputUnits > 0 ? (otCost === null ? NEEDS_PAYROLL : null) : NEEDS_OUTPUT,
  });

  rows.push({
    companyId: null,
    category: 'total',
    metric: 'cost_per_man_hour',
    value: totalWorkedHours > 0 && grossSalary !== null ? grossSalary / totalWorkedHours : null,
    unavailableReason: totalWorkedHours > 0 ? (grossSalary === null ? NEEDS_PAYROLL : null) : 'No worked hours in period',
  });

  rows.push({
    companyId: null,
    category: 'total',
    metric: 'cost_per_unit',
    value: outputUnits > 0 && grossSalary !== null ? grossSalary / outputUnits : null,
    unavailableReason: outputUnits > 0 ? (grossSalary === null ? NEEDS_PAYROLL : null) : NEEDS_OUTPUT,
  });

  // Composite burnout index proxy (0-100 scale)
  const otPerHead = totalActive > 0 ? otHours / totalActive : 0;
  const absRate = scheduled === 0 ? 0 : (Number(absence?.absent ?? 0) / scheduled) * 100;
  const burnoutScore = Math.min(100, Math.round(((otPerHead * 2.5) + (absRate * 1.5)) * 10) / 10);
  rows.push({
    companyId: null,
    category: 'total',
    metric: 'burnout_index',
    value: burnoutScore,
    unavailableReason: null,
  });

  // ── Plant-level metrics per company ───────────────────────────────────────
  const companies = await db.selectFrom('core.companies').select(['id']).execute();
  for (const comp of companies) {
    const compHeadcount = await db
      .selectFrom('core.employees')
      .select((eb) => eb.fn.countAll<string>().as('n'))
      .where('company_id', '=', comp.id)
      .where('status', 'in', ['active', 'on_notice'])
      .executeTakeFirst();
    const compTotal = Number(compHeadcount?.n ?? 0);
    rows.push({
      companyId: comp.id,
      category: 'total',
      metric: 'manpower_count',
      value: compTotal,
    });

    const compAbsence = await db
      .selectFrom('att.day_records as d')
      .innerJoin('core.employees as e', 'e.id', 'd.employee_id')
      .select(sql<string>`COUNT(*) FILTER (WHERE d.status IN ('A','UAB'))`.as('absent'))
      .select(sql<string>`COUNT(*) FILTER (WHERE d.status NOT IN ('WO','H'))`.as('scheduled'))
      .where('e.company_id', '=', comp.id)
      .where('d.work_date', '>=', sql<Date>`${monthStart}::date`)
      .where('d.work_date', '<=', sql<Date>`${date}::date`)
      .executeTakeFirst();
    const compSched = Number(compAbsence?.scheduled ?? 0);
    rows.push({
      companyId: comp.id,
      category: 'total',
      metric: 'absenteeism_pct',
      value: compSched === 0 ? null : (Number(compAbsence?.absent ?? 0) / compSched) * 100,
      unavailableReason: compSched === 0 ? 'No processed attendance in this period' : null,
    });

    const compOt = await db
      .selectFrom('att.day_records as d')
      .innerJoin('core.employees as e', 'e.id', 'd.employee_id')
      .select(sql<string>`COALESCE(SUM(d.ot_minutes), 0)`.as('minutes'))
      .where('e.company_id', '=', comp.id)
      .where('d.work_date', '>=', sql<Date>`${monthStart}::date`)
      .where('d.work_date', '<=', sql<Date>`${date}::date`)
      .executeTakeFirst();
    rows.push({
      companyId: comp.id,
      category: 'total',
      metric: 'overtime_hours',
      value: Number(compOt?.minutes ?? 0) / 60,
    });
  }

  // Replace the day's rows atomically — a half-written snapshot would be read
  // by the dashboard as though it were complete.
  await db.transaction().execute(async (trx) => {
    await trx
      .deleteFrom('reporting.kpi_daily')
      .where('snapshot_date', '=', sql<Date>`${date}::date`)
      .execute();
    await trx
      .insertInto('reporting.kpi_daily')
      .values(
        rows.map((r) => ({
          snapshot_date: sql<Date>`${date}::date` as unknown as Date,
          company_id: r.companyId,
          category: r.category,
          metric: r.metric,
          value: r.value === null ? null : String(r.value),
          unavailable_reason: r.unavailableReason ?? null,
        })),
      )
      .execute();
  });

  return { snapshotDate: date, metrics: rows.length };
}

/** Read the most recent snapshot on or before `date`. Never aggregates. */
export async function readKpiSnapshot(
  db: Kysely<Database>,
  params: { date?: string | undefined } = {},
): Promise<KpiSnapshot | null> {
  const asOf = params.date ?? istDateString();
  const latest = await db
    .selectFrom('reporting.kpi_daily')
    .select(['snapshot_date'])
    .where('snapshot_date', '<=', sql<Date>`${asOf}::date`)
    .orderBy('snapshot_date', 'desc')
    .limit(1)
    .executeTakeFirst();
  if (!latest) return null;

  const rows = await db
    .selectFrom('reporting.kpi_daily')
    .selectAll()
    .where('snapshot_date', '=', latest.snapshot_date)
    .orderBy('metric')
    .execute();

  const first = rows[0];
  return {
    snapshotDate: formatDbDate(latest.snapshot_date),
    computedAt:
      first?.computed_at instanceof Date ? first.computed_at.toISOString() : null,
    metrics: rows.map((r) => ({
      companyId: r.company_id,
      category: r.category,
      metric: r.metric,
      value: r.value === null ? null : Number(r.value),
      unavailableReason: r.unavailable_reason,
    })),
  };
}

/**
 * KPI trend — the same precomputed rows, read across time (docs/06 §4:
 * "absenteeism %, monthly trend"; §5 BU dashboard "absenteeism trend").
 *
 * Still no aggregation: this reads `reporting.kpi_daily`, which the nightly job
 * already wrote. A month with no snapshot comes back as `null` rather than 0 —
 * the chart breaks its line at a gap instead of drawing a false dip to zero.
 */
export async function kpiTrend(
  db: Kysely<Database>,
  params: { metric: string; months?: number | undefined; category?: string | undefined },
): Promise<{ label: string; date: string; value: number | null }[]> {
  const months = Math.min(Math.max(params.months ?? 6, 1), 24);
  const category = params.category ?? 'total';

  // One row per month: the LAST snapshot in each month is that month's value.
  const rows = await sql<{ month: string; value: string | null }>`
    SELECT to_char(date_trunc('month', snapshot_date), 'YYYY-MM') AS month,
           (array_agg(value ORDER BY snapshot_date DESC))[1] AS value
      FROM reporting.kpi_daily
     WHERE metric = ${params.metric}
       AND category = ${category}
       AND snapshot_date >= (date_trunc('month', CURRENT_DATE) - ${months - 1} * INTERVAL '1 month')
     GROUP BY 1
     ORDER BY 1
  `.execute(db);

  const byMonth = new Map(rows.rows.map((r) => [r.month, r.value]));

  // Emit EVERY month in the window, so a gap is visible as a gap.
  const out: { label: string; date: string; value: number | null }[] = [];
  const now = new Date();
  for (let i = months - 1; i >= 0; i--) {
    const d = new Date(Date.UTC(now.getUTCFullYear(), now.getUTCMonth() - i, 1));
    const key = `${String(d.getUTCFullYear())}-${String(d.getUTCMonth() + 1).padStart(2, '0')}`;
    const raw = byMonth.get(key);
    out.push({
      label: d.toLocaleDateString('en-IN', { month: 'short', timeZone: 'UTC' }),
      date: key,
      value: raw === undefined || raw === null ? null : Number(raw),
    });
  }
  return out;
}
