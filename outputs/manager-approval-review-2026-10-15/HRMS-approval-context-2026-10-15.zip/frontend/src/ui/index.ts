/**
 * Warm Editorial component kit (docs/05 §5) — the ONLY UI system in the product
 * (docs/05 §0.1 firewall: no second component library, ever). Every screen
 * composes from here; screens never invent primitives.
 *
 * Stage 0.3 status: core primitives + Crextio-signature set + theme +
 * data/detail surfaces + form vocabulary (TextField/Textarea/Select/DatePicker/
 * Checkbox/Switch) + feedback layer (Toast/Skeleton/Tooltip) + FilterPanel +
 * MonthCalendar shipped. Module-phase composites (RosterGrid, ApprovalInbox,
 * Stepper, ⌘K palette) land with their phases (1–2).
 */

export { cn } from './cn';
export { useTheme } from './theme';
export type { ThemeMode } from './theme';
export { ThemeToggle } from './ThemeToggle';

export { Button } from './Button';
export { IconButton } from './IconButton';
export { PageHeader } from './PageHeader';
export { Card, CardHeader } from './Card';
export { DarkCard } from './DarkCard';
export { StatusBadge, Pill } from './StatusBadge';
export type { StatusTone } from './StatusBadge';
export { KpiNumber } from './KpiNumber';

export { HatchFill } from './HatchFill';
export { KpiPillRow } from './KpiPillRow';
export type { KpiPill, PillState } from './KpiPillRow';
export { SegmentedProgress } from './SegmentedProgress';
export { DotMatrix } from './DotMatrix';
export type { Dot, DotState } from './DotMatrix';

// Form vocabulary — same doctrine on every screen (docs/05 §7b).
export { TextField } from './TextField';
export { Textarea } from './Textarea';
export { Select } from './Select';
export type { SelectOption } from './Select';
export { DatePicker } from './DatePicker';
export { Checkbox } from './Checkbox';
export { Switch } from './Switch';

// Feedback layer — how the product acknowledges action (docs/05 §6).
export { Toaster, toast } from './Toast';
export { Skeleton } from './Skeleton';
export { Tooltip } from './Tooltip';

export { TrendChart, BarChart } from './Chart';
export type { ChartPoint } from './Chart';

export { DataTable } from './DataTable';
export type { Column } from './DataTable';
export { Drawer } from './Drawer';
export { ConfirmModal } from './ConfirmModal';
export { EmptyState } from './EmptyState';
export { Timeline } from './Timeline';
export type { TimelineStep, TimelineState } from './Timeline';

export { FilterPanel, FilterSection } from './FilterPanel';
export { MonthCalendar } from './MonthCalendar';
export type { AttendanceDay, AttendanceDayState } from './MonthCalendar';
export { formatDateIN, todayISOIST } from './calendar';
export type { CalendarDay } from './calendar';
